# Aeryvex Pro — Galactic Arena 3D recovery build

Godot 3.5/3.6 project with procedurally generated arena, nine **placeholder** fighters, 3D movement, lightsaber hit detection, health/guard, block, dodge, force push, rudimentary pursuit AI and five selectable prototype modes. It is a functional **development prototype**, **not** the finished game or the high-fidelity character pipeline referenced in HANDOFF.md.

## Run locally
Open project.godot in Godot 3.x, then press F6/F5. Godot 4 is not compatible with these scripts.

## Controls
WASD move; J light; K heavy; L block; Space dodge; F force push; H cycle fighter; M cycle mode; R restart; P pause; Q/E orbit; Xbox face buttons, LB/RB and Start where supported.

## Kaggle
Kaggle's free T4 GPUs support Python/CUDA jobs, but Kaggle notebooks do not provide a reliable real-time graphical Godot game runtime. Use Kaggle for asset generation; export files and test real-time gameplay locally or in CI. Code is available in this ZIP and can be uploaded to Kaggle as an input Dataset.

## Limitations
- Procedural primitives stand in for character models; no real skeletons or 21 animation assets were recovered.
- Story, skirmish and training are prototype rule variants, not content-complete campaigns.
- No Godot executable is installed in this authoring container; project is authored but **not runtime tested**.
- Offline single-player; no licensing guarantee for external franchise characters or visual likenesses.

## Go 1 foundation update (2026-10-24)
- Added local JSON progress saving for wins and character selection (`user://aeryvex_progress.json`).
- Fixed heavy attack stamina checks and reset AI decision timer on match restart.
- Added dependency-free structural smoke checks: `python3 tests/check_project.py`.
- Gameplay has **not** been launched in Godot in this environment; the checks do not certify runtime behavior.
- This build still uses placeholder geometry and recognizable franchise characters; it is **not cleared for commercial sale**.

## Go 2 — movement, camera, controller (2026-10-24)
- Camera-relative movement with acceleration/deceleration and proper analog deadzones.
- WASD and left stick use one InputMap path (no doubled input speed); diagonal travel is capped.
- Shift/left trigger sprint drains stamina; blocking slows movement and prevents sprint.
- Q/E or right stick to orbit horizontally; right stick to tilt; hold **right mouse button and drag** to orbit; scroll to zoom; **C or press right stick** to recenter.
- Arena movement boundaries clamp position; dodge goes with the held movement direction, or backward if neutral.
- Pausing now updates the HUD, and menu/mode changes are ignored until unpaused.
- `python3 tests/check_project.py && python3 tests/check_go2.py` verifies static source invariants.
- `godot3 --no-window --path . -s res://tests/runtime_smoke.gd` runs Godot-engine runtime checks when Godot 3.x is installed (not executed in the authoring container).

**Still missing:** production-quality animations, art, complete modes, gameplay certification and commercial-safe assets. The controller axis mappings can differ by controller/driver; test on the target Xbox controller and remap as needed. Godot 4 is incompatible with this Godot 3.x project.

## Go 3 — timed melee, parrying and guard breaks (2026-10-24)
- Replaced instant-distance attack damage with a timed **windup → active hit → recovery** strike cycle; every strike resolves its hit at most once.
- Light/heavy attacks have different damage, range, stamina costs, commitment, and recovery. They use forward-facing arc and planar range checks, not an all-around distance sphere.
- Sword pivot now visibly winds up and follows through; one queued follow-up attack is allowed late in recovery.
- Holding block reduces damage but drains guard; a fresh block press provides a 0.24-second parry opportunity that briefly staggers the attacker. Heavy hits can break low guard and stagger the defender.
- Dodge invulnerability overrides damage. Guard checks only apply from the defender's facing direction. Force push retains a separate cooldown and bypasses sword guard.
- Enemy attacks use the same timed hit/damage rules and may react with blocking/parrying.
- Extracted deterministic parameters and damage decisions into `scripts/CombatRules.gd` to simplify tuning and future in-engine testing.

**Run source checks:** `python3 tests/check_project.py && python3 tests/check_go2.py && python3 tests/check_go3.py`

**Run in-engine tests on a machine with Godot 3.5/3.6:**
```
godot3 --no-window --path . -s res://tests/runtime_smoke.gd
godot3 --no-window --path . -s res://tests/runtime_combat.gd
```
Some installations use `godot` rather than `godot3` as the command. Open `project.godot` in Godot 3.6 and press F5 to play, too. This archive's source checks were run, but **Godot compilation, rendering and interactive combat tests have not yet been run in the authoring environment**.

**Not production ready:** rigged fighters/animation assets, complete story and large battle modes, full visual/audio polish, frame-rate measurement, commercial-ready replacement for franchise content and end-to-end platform testing remain outstanding. This go focuses on core combat code, not those deliverables.


## Go 4 — modular 3D fighters and real-time joint animation (2026-10-24)
- Replaced the rigid block-only fighter visuals with a **hierarchical articulated character proxy** (`scripts/FighterVisual.gd`). Each fighter has transform pivots for head, torso, shoulders, elbows, hips, knees, and a hand-mounted saber. The default body geometry uses simple 3D meshes, not final character scans.
- Nine identities get differentiated silhouettes through size, clothing/armor palettes, hair or helmet, robe drapes, and other modular details. This remains **prototype art**, not realistic finished character models or a skinned skeleton.
- A frame-driven animation controller now blends walk cycles, breathing, light/heavy windups, impact follow-through, defensive stance, dodge/stagger reactions and a defeat lean. Enemy and player call the same rig driver. The weapon is attached to the wrist so it follows the arm.
- Existing gameplay and hit detection remain on the root fighter transform. Combat rules, game modes, camera and saved progress were retained.
- Go 4 static check: `python3 tests/check_go4.py`; in-engine test: `godot3 --no-window --path . -s res://tests/runtime_animation.gd`.
- **Unverified in engine in this environment:** needs startup/rendering verification and interactive visual review in Godot 3.6. This is a material animation foundation, not the previously described realistic production asset pipeline.

## Go 5 — defensive AI, difficulty, animation polish (2026-10-24)
- The opponent now pursues at tactical distance, circles the player, backs away if crowded, uses an attack timer, chooses blocks/parries after difficulty-scaled reaction delays, and dodges when guard is low (stamina and cooldown gated).
- Press **T** to switch AI difficulty: Rookie → Veteran → Master. The selection is stored in the same JSON progress save, with a sensible default for older saves.
- Enemy attack windups are called out on the HUD; the procedural animation blend is less sensitive to frame rate, with more expressive torso and guard poses.
- A fatal strike that immediately starts the next Survival/Training opponent can no longer continue processing the old strike after respawn.
- Added `scripts/EnemyBrain.gd` and a Godot regression test `tests/runtime_ai.gd` with deterministic tactical decisions. Added `tools/run_godot_tests.sh` to run all four engine suites.

**Check source offline** (no GPU needed):
```
python3 tests/check_project.py
python3 tests/check_go2.py
python3 tests/check_go3.py
python3 tests/check_go4.py
python3 tests/check_go5.py
```

**Test in your installed Godot 3.5/3.6** (from this project folder):
```
bash tools/run_godot_tests.sh
```
If Godot is not in PATH, set `GODOT_BIN=/full/path/to/godot` before that command. To play, open `project.godot` in Godot 3.6 and press F5. The source was statically checked, **not** launched or visually verified by the authoring environment.

## Go 6 update
Duel is now a best-of-three match. A knocked-out round pauses the duel; press **N** for the next round, **R** to restart the full match. Wins count only after a match victory. Other modes continue using their existing flow. See `PLAYER_FEATURE_ROADMAP.md` for additional player-requested features, which are not yet implemented.


## Go 7 — Galactic Fronts objective prototype
Press M to cycle modes until **Fronts**. Three control points (left, center, right) capture by standing within 3 meters without an opponent contesting. The HUD shows ownership (A allied, E enemy, - neutral), and ticket totals. Holding a majority drains opposing tickets; eliminating a fighter also costs eight tickets and respawns both fighters. First team to exhaust tickets loses. Press R to restart. This is two-fighter objective gameplay, **not** finished troop squads, vehicles, or conquest.

Run `python tests/check_go7.py` for source checks and `godot3 --path . -s tests/runtime_fronts.gd` for headless rules tests when Godot 3.x is available. Full gameplay runtime tests remain outstanding.
